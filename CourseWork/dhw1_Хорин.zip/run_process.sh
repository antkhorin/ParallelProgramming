javac Process.java
java Process $1